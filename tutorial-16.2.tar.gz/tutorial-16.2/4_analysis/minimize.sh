grep INFO ../3_qmmm/qmmm_min.out >& minimize.log
gnuplot minimize.gpi
