#!/bin/bash

# Generate QM/MM systems
export PATH=/path/to/genesis/bin:$PATH

qmmm_generator qmmm_generator.inp >& qmmm_generator.out

