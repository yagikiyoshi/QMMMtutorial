gfortran mk_initial_path.f90 -o mk_initial_path
./mk_initial_path ../../3.min/qmmm_min1.pdb ../../3.min/qmmm_min2b.pdb 16
